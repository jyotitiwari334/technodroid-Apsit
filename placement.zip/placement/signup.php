<!DOCTYPE html>
<html>
    <head>
        <meta name="format-detection" content="telephone=no">
        <meta name="msapplication-tap-highlight" content="no">
        <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
        <link rel="stylesheet" type="text/css" href="sign.css">
		<link rel="stylesheet" type="text/css" href='styling.css' />
        <title>Login</title>
    </head>
    <body>
	
<style>
.error-message {
	padding: 7px 10px;
	background: #fff1f2;
	border: #ffd5da 1px solid;
	color: #d6001c;
	border-radius: 4px;
}
.success-message {
	padding: 7px 10px;
	background: #cae0c4;
	border: #c3d0b5 1px solid;
	color: #027506;
	border-radius: 4px;
}
.demo-table {
	background: #d9eeff;
	width: 100%;
	border-spacing: initial;
	margin: 2px 0px;
	word-break: break-word;
	table-layout: auto;
	line-height: 1.8em;
	color: #333;
	border-radius: 4px;
	padding: 20px 40px;
}
.demo-table td {
	padding: 15px 0px;
}
.demoInputBox {
	padding: 10px 30px;
	border: #a9a9a9 1px solid;
	border-radius: 4px;
}
.btnRegister {
	padding: 10px 30px;
	background-color: #3367b2;
	border: 0;
	color: #FFF;
	cursor: pointer;
	border-radius: 4px;
	margin-left: 10px;
}
</style>
	
        <div class="loginbox">
    <center>
        <br>
        <h1>SIGNUP</h1>
        <form>
        
        <strong>Name:</strong> <br>
            <input id="f_name" type="text" placeholder="First">
            <input id="m_name" type="text" placeholder="Middle">
            <input id="l_name" type="text" placeholder="Last"><br><br>

	<strong>
	<form action="/action_page.php">
  		Date Of Birth:
  			<input type="date" name="date" class="demoInputBox">
	</form></strong>
	<br><br>
            
        <strong>E-mail ID:</strong>
            <input id="email" type="email" class="demoInputBox" placeholder="example@gmail.com"><br><br>
            
        <strong>Contact no:</strong>
            <input id="contact" type="integer" class="demoInputBox" placeholder="Number"><br><br>

	<strong>Educational Qualification:</strong><br>
	     SSC:<input id="ssc" type="float" class="demoInputBox" placeholder="%"><br>
	     HSC:<input id="hsc" type="float" class="demoInputBox" placeholder="%"><br>
	     <strong><t>ENGINEERING : </strong><br>
		<t>SEM1:<input id="s1" type="float" class="demoInputBox" placeholder="CGPI"><br>
		<t>SEM2:<input id="s2" type="float" class="demoInputBox" placeholder="CGPI"><br>
		<t>SEM3:<input id="s3" type="float" class="demoInputBox" placeholder="CGPI"><br>
		<t>SEM4:<input id="s4" type="float" class="demoInputBox" placeholder="CGPI"><br>
		<t>SEM5:<input id="s5" type="float" class="demoInputBox" class="demoInputBox" placeholder="CGPI"><br>
		<t>SEM6:<input id="s6" type="float" class="demoInputBox" placeholder="CGPI"><br>
		<t>SEM7:<input id="s7" type="float" class="demoInputBox" placeholder="CGPI"><br>
		<t>SEM8:<input id="s8" type="float" class="demoInputBox" placeholder="CGPI"><br><br>

	    <form>
   	    <strong><t>ENTER YOUR CHOICE : </strong><br><br>
            <input type="checkbox" name="placement" value="placement"> PLACEMENT<br>
            <input type="checkbox" name="HighEdu" value="higheducation"> HIGHER EDUCATION <br>
            <input type="checkbox" name="ForeignEdu" value="foreignedu"> FOREIGN EDUCATION<br>
            <input type="checkbox" name="interpreneurship" value="interprenureship"> INTERPRENERSHIP<br> 
            </form> <br><br>

            
            <input id="sub" type="button" value="Submit" class="btnRegister" onclick="subform();">
            <input id="res" type="reset" Value="Reset" class="btnRegister"><br>
            <center><a href="index.html" > </a></center>
        
        </form>
    
	    <script type="text/javascript" src="js/save.js"></script>
       <script type="text/javascript" src="cordova.js"></script>
        <script type="text/javascript" src="js/index.js"></script>
        <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
    </center>
        </body>
</html>